<?php
session_start();
$USERS_FILE = __DIR__ . '/users.json';
if (!file_exists($USERS_FILE)) file_put_contents($USERS_FILE, json_encode([], JSON_PRETTY_PRINT));

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '' || $full_name === '') {
        $error = "All fields are required.";
    } else {
        $users = json_decode(file_get_contents($USERS_FILE), true);
        foreach ($users as $u) {
            if (strcasecmp($u['username'], $username) === 0) {
                $error = "Username already exists.";
                break;
            }
        }
        if (!$error) {
            $users[] = [
                'username' => $username,
                'full_name' => $full_name,
                'password' => password_hash($password, PASSWORD_DEFAULT)
            ];
            file_put_contents($USERS_FILE, json_encode($users, JSON_PRETTY_PRINT));
            $_SESSION['username'] = $username;
            $_SESSION['full_name'] = $full_name;
            header("Location: dashboard.php");
            exit();
        }
    }
}
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Register - CoinManager</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
    <h1>Register</h1>
    <?php if ($error): ?>
        <div class="error-message"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="post" action="">
        <input type="text" name="full_name" placeholder="Full Name" value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>" required><br>
        <input type="text" name="username" placeholder="Username" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required><br>
        <input type="password" name="password" placeholder="Password" required><br>
        <button type="submit">Register</button>
    </form>
    <p>Already have an account? <a href="login.php">Login here</a></p>
    <p><a href="index.php">Back to Home</a></p>
</div>
</body>
</html>
