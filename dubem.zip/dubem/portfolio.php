<?php
session_start();
if(!isset($_SESSION['username'])){ header("Location: login.php"); exit(); }

$PORT_FILE = __DIR__.'/portfolio.json';
if(!file_exists($PORT_FILE)) file_put_contents($PORT_FILE,json_encode(new stdClass(),JSON_PRETTY_PRINT));

$username = $_SESSION['username'];
$portData = json_decode(file_get_contents($PORT_FILE),true);
$userPortfolio = $portData[$username] ?? [];

$action = $_POST['action']??'';
$coin = strtoupper($_POST['coin']??'');
$amount = floatval($_POST['amount']??0);
$index = intval($_POST['index']??-1);

if($action==='add' && $coin && $amount>0){
    $userPortfolio[]=['coin'=>$coin,'amount'=>$amount];
}
elseif($action==='edit' && $index>=0 && isset($userPortfolio[$index])){
    $userPortfolio[$index]['amount']=$amount;
}
elseif($action==='remove' && $index>=0 && isset($userPortfolio[$index])){
    array_splice($userPortfolio,$index,1);
}

$portData[$username]=$userPortfolio;
file_put_contents($PORT_FILE,json_encode($portData,JSON_PRETTY_PRINT));
header("Location: dashboard.php");
exit();
