<?php
session_start();
if (isset($_SESSION['username'])) {
    header("Location: dashboard.php");
    exit();
}

// Sample coins for ticker
$tickerCoins = ['bitcoin','ethereum','binancecoin','cardano','dogecoin'];
$prices = [];
foreach ($tickerCoins as $coin) {
    $url = "https://api.coingecko.com/api/v3/simple/price?ids={$coin}&vs_currencies=usd";
    $res = @file_get_contents($url);
    if ($res) $prices[$coin] = json_decode($res, true)[$coin]['usd'];
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>CoinManager Home</title>
<style>
body {
    margin: 0;
    padding: 0;
    font-family: 'Arial', sans-serif;
    background: linear-gradient(to right, #00c6ff, #0072ff);
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}
.container {
    background: #fff;
    padding: 40px 50px;
    border-radius: 12px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.2);
    text-align: center;
    width: 450px;
}
h1 {
    font-size: 34px;
    color: #007bff;
    margin-bottom: 15px;
}
h2 {
    font-size: 20px;
    margin-top: 25px;
    color: #333;
}
p {
    font-size: 16px;
    margin-top: 15px;
    color: #555;
}
a {
    text-decoration: none;
    color: #fff;
    background-color: #007bff;
    padding: 10px 25px;
    margin: 10px 5px;
    border-radius: 8px;
    transition: 0.3s;
    font-weight: bold;
    display: inline-block;
}
a:hover {
    background-color: #0056b3;
}
#ticker {
    background: #f1f1f1;
    padding: 8px 0;
    margin: 20px 0;
    overflow: hidden;
    white-space: nowrap;
    font-weight: bold;
    border-radius: 6px;
}
#ticker span {
    display: inline-block;
    padding: 0 30px;
}
.features {
    text-align: left;
    margin-top: 20px;
}
.features li {
    margin: 8px 0;
}
@media (max-width: 480px) {
    .container {
        width: 90%;
        padding: 30px 20px;
    }
    h1 { font-size: 28px; }
    h2 { font-size: 18px; }
    p { font-size: 14px; }
    a { padding: 8px 18px; font-size: 14px; }
}
</style>
</head>
<body>
<div class="container">
    <h1>Welcome to CoinManager</h1>
    <p>Track your crypto portfolio, manage coins, and see live prices in USD and crypto!</p>

    <!-- Live ticker -->
    <div id="ticker">
        <?php foreach ($prices as $coin => $price): ?>
            <span><?= strtoupper($coin) ?>: $<?= number_format($price,2) ?></span>
        <?php endforeach; ?>
    </div>

    <h2>Features</h2>
    <ul class="features">
        <li>✅ Add, edit, and remove coins</li>
        <li>✅ Track portfolio balance in USD & crypto</li>
        <li>✅ Live CoinGecko price updates</li>
        <li>✅ Secure user login & dashboard</li>
        <li>✅ Admin panel to manage users & portfolios</li>
    </ul>

    <p>
        <a href="register.php">Register</a> | 
        <a href="login.php">Login</a>
    </p>
</div>

<script>
// Simple ticker scroll effect
function scrollTicker() {
    const ticker = document.getElementById('ticker');
    ticker.scrollLeft += 1;
}
setInterval(scrollTicker, 50);
</script>
</body>
</html>
