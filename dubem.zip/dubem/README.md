# 🪙 CoinManager – Crypto Portfolio Web App

A complete cryptocurrency portfolio tracking website with admin panel, live price updates, and user dashboard — built with PHP, HTML, CSS, and JavaScript.

## 🚀 Features
- 📊 Live crypto prices using CoinGecko API  
- 👤 User dashboard with portfolio summary  
- 🛠️ Admin panel to manage users and coins  
- 💼 Add / Edit / Remove coins easily  
- 🔐 Secure login & logout system  
- 📱 Fully responsive on mobile and desktop

## 🧰 Tech Stack
- PHP (Backend)
- HTML, CSS, JavaScript (Frontend)
- JSON (Data Storage)
- CoinGecko API (Real-time prices)

## 📦 Installation
1. Clone this repository:
   ```bash
   git clone https://github.com/dubizle/coin-portfolio.git
