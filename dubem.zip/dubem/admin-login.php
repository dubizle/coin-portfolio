<?php
session_start();
define('ADMIN_USER','admin');
define('ADMIN_PASS','admin123');
$error='';

if($_SERVER['REQUEST_METHOD']==='POST'){
    $user = $_POST['username']??'';
    $pass = $_POST['password']??'';
    if($user === ADMIN_USER && $pass === ADMIN_PASS){
        $_SESSION['is_admin']=true;
        header("Location: admin.php");
        exit();
    } else {
        $error="Invalid admin credentials.";
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Admin Login - CoinManager</title>
<style>
body {
    margin:0;padding:0;font-family:Arial,sans-serif;
    background: linear-gradient(to right,#00c6ff,#0072ff);
    display:flex;justify-content:center;align-items:center;height:100vh;
}
.container {
    background:#fff;padding:40px 50px;border-radius:12px;
    box-shadow:0 8px 25px rgba(0,0,0,0.2);text-align:center;width:350px;
}
h1 {color:#007bff;margin-bottom:25px;}
input {width:100%;padding:10px;margin:10px 0;border:1px solid #ccc;border-radius:6px;}
button {width:100%;padding:10px;background:#007bff;color:#fff;border:none;border-radius:6px;cursor:pointer;font-weight:bold;}
button:hover {background:#0056b3;}
.error-message {color:red;margin-bottom:15px;}
a {text-decoration:none;color:#007bff;}
</style>
</head>
<body>
<div class="container">
<h1>Admin Login</h1>
<?php if($error) echo "<div class='error-message'>".htmlspecialchars($error)."</div>"; ?>
<form method="post">
<input type="text" name="username" placeholder="Admin username" required>
<input type="password" name="password" placeholder="Password" required>
<button type="submit">Login</button>
</form>
<p><a href="index.php">Back to Home</a></p>
</div>
</body>
</html>
