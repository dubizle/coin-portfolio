<?php
session_start();
if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit();
}

// Logout
if(isset($_GET['action']) && $_GET['action']==='logout'){
    session_destroy();
    header("Location: index.php");
    exit();
}

$PORT_FILE = __DIR__.'/portfolio.json';
if(!file_exists($PORT_FILE)) file_put_contents($PORT_FILE, json_encode(new stdClass(), JSON_PRETTY_PRINT));

$username = $_SESSION['username'];
$full_name = $_SESSION['full_name'] ?? $username;

// Load user portfolio
$portData = json_decode(file_get_contents($PORT_FILE), true);
$userPortfolio = $portData[$username] ?? [];

// Fixed coins for dashboard
$coins_list = ['BTC'=>'bitcoin','ETH'=>'ethereum','BNB'=>'binancecoin','ADA'=>'cardano','DOGE'=>'dogecoin','SOL'=>'solana','XRP'=>'ripple','LTC'=>'litecoin','DOT'=>'polkadot'];

// Fetch live prices from CoinGecko
$coinIds = array_values($coins_list);
$api_url = 'https://api.coingecko.com/api/v3/simple/price?ids='.implode(',', $coinIds).'&vs_currencies=usd';
$response = @file_get_contents($api_url);
$prices = $response ? json_decode($response,true) : [];

// Calculate portfolio values
$totalUSD = 0;
foreach($userPortfolio as &$item){
    $id = $coins_list[strtoupper($item['coin'])] ?? null;
    $price = $id ? ($prices[$id]['usd'] ?? 0) : 0;
    $item['price'] = $price;
    $item['value'] = $item['amount'] * $price;
    $totalUSD += $item['value'];
}
unset($item);
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Dashboard - CoinManager</title>
<link rel="stylesheet" href="css/style.css">
<style>
body { font-family:Arial,sans-serif; background:#f7f8fa; }
nav { background:#007bff; color:#fff; padding:10px; display:flex; justify-content:space-between; }
nav a { color:#fff; text-decoration:none; margin-left:10px; }
.container { max-width:900px; margin:20px auto; background:#fff; padding:20px; border-radius:10px; box-shadow:0 0 15px rgba(0,0,0,0.1); }
table th,table td { text-align:center; padding:8px; border:1px solid #ddd; }
table th { background:#007bff; color:#fff; }
#ticker { background:#eee; padding:10px; overflow:hidden; white-space:nowrap; margin-bottom:15px; font-weight:bold; }
#ticker span { display:inline-block; padding:0 30px; }
button { padding:6px 12px; margin:2px; border-radius:4px; border:none; cursor:pointer; }
button.add { background:#28a745;color:#fff; }
button.edit { background:#ffc107;color:#fff; }
button.remove { background:#dc3545;color:#fff; }
</style>
</head>
<body>

<nav>
<div>💰 CoinManager - <?= htmlspecialchars($full_name) ?></div>
<div>
<a href="dashboard.php">Dashboard</a> |
<a href="dashboard.php?action=logout" style="color:red;">Logout</a>
</div>
</nav>

<div class="container">
<h1>Portfolio</h1>
<p>Total Portfolio Value: <strong>$<?= number_format($totalUSD,2) ?></strong></p>

<!-- Ticker -->
<div id="ticker">
<?php foreach($coins_list as $sym=>$id):
$price = $prices[$id]['usd']??0;
?>
<span data-coin="<?=$id?>"><?=$sym?>: $<?=number_format($price,2)?></span>
<?php endforeach;?>
</div>

<!-- Add Coin Form -->
<h2>Add Coin</h2>
<form method="post" action="portfolio.php" style="margin-bottom:16px;">
<input type="hidden" name="action" value="add">
<select name="coin" required>
<option value="">Select Coin</option>
<?php foreach($coins_list as $sym=>$id): ?>
<option value="<?= $sym ?>"><?= $sym ?></option>
<?php endforeach; ?>
</select>
<input type="number" step="0.00000001" name="amount" placeholder="Amount" required>
<button type="submit" class="add">Add</button>
</form>

<!-- Portfolio Table -->
<table>
<thead>
<tr><th>Coin</th><th>Amount</th><th>Price (USD)</th><th>Value (USD)</th><th>Actions</th></tr>
</thead>
<tbody>
<?php foreach($userPortfolio as $index=>$item): ?>
<tr data-coin="<?= strtolower($item['coin']) ?>">
<td><?= strtoupper($item['coin']) ?></td>
<td><?= $item['amount'] ?></td>
<td><?= '$'.number_format($item['price'],2) ?></td>
<td><?= '$'.number_format($item['value'],2) ?></td>
<td>
<form method="post" action="portfolio.php" style="display:inline;">
<input type="hidden" name="action" value="edit">
<input type="hidden" name="index" value="<?= $index ?>">
<input type="number" step="0.00000001" name="amount" placeholder="New amount" required>
<button type="submit" class="edit">Edit</button>
</form>
<form method="post" action="portfolio.php" style="display:inline;">
<input type="hidden" name="action" value="remove">
<input type="hidden" name="index" value="<?= $index ?>">
<button type="submit" class="remove" onclick="return confirm('Remove this coin?')">Remove</button>
</form>
</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>

<script>
// Auto-refresh prices every 10s
const coins = <?= json_encode(array_values($coins_list)) ?>;
async function updatePrices(){
try{
const res = await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${coins.join(',')}&vs_currencies=usd`);
const data = await res.json();
coins.forEach(coin=>{
const row = document.querySelector(`tr[data-coin="${coin}"]`);
const tickerSpan = document.querySelector(`#ticker span[data-coin="${coin}"]`);
const price = data[coin]?.usd??0;
if(row) { 
    row.cells[2].innerText = '$'+price.toFixed(2);
    const amount = parseFloat(row.cells[1].innerText);
    row.cells[3].innerText = '$'+(price*amount).toFixed(2);
}
if(tickerSpan) tickerSpan.innerText = coin.toUpperCase()+': $'+price.toFixed(2);
});
}catch(err){ console.error(err); }
}
setInterval(updatePrices,10000);
updatePrices();

// Scroll ticker
function scrollTicker(){
document.getElementById('ticker').scrollLeft +=1;
}
setInterval(scrollTicker,50);
</script>

</body>
</html>
