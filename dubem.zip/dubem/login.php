<?php
session_start();
$USERS_FILE = __DIR__ . '/users.json';
if (!file_exists($USERS_FILE)) file_put_contents($USERS_FILE, json_encode([], JSON_PRETTY_PRINT));

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = "Enter username and password.";
    } else {
        $users = json_decode(file_get_contents($USERS_FILE), true);
        $found = null;
        foreach ($users as $u) {
            if (strcasecmp($u['username'], $username) === 0) {
                $found = $u;
                break;
            }
        }
        if ($found && password_verify($password, $found['password'])) {
            $_SESSION['username'] = $found['username'];
            $_SESSION['full_name'] = $found['full_name'];
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Invalid username or password.";
        }
    }
}
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Login - CoinManager</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
    <h1>Login</h1>
    <?php if ($error): ?>
        <div class="error-message"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="post" action="">
        <input type="text" name="username" placeholder="Username" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required><br>
        <input type="password" name="password" placeholder="Password" required><br>
        <button type="submit">Login</button>
    </form>
    <p>No account? <a href="register.php">Register here</a></p>
    <p><a href="index.php">Back to Home</a></p>
</div>
</body>
</html>
