<?php
session_start();
if(!($_SESSION['is_admin']??false)) exit();

$USERS_FILE = __DIR__.'/users.json';
$PORT_FILE = __DIR__.'/portfolio.json';

$users = json_decode(file_get_contents($USERS_FILE),true);
$portfolios = json_decode(file_get_contents($PORT_FILE),true);

$action = $_POST['action']??'';
$username = $_POST['username']??'';

if($action==='delete_user' && $username){
    // Remove user
    foreach($users as $i=>$u){
        if($u['username']===$username) unset($users[$i]);
    }
    unset($portfolios[$username]);
    file_put_contents($USERS_FILE,json_encode(array_values($users),JSON_PRETTY_PRINT));
    file_put_contents($PORT_FILE,json_encode($portfolios,JSON_PRETTY_PRINT));
}

header("Location: admin.php");
exit();
