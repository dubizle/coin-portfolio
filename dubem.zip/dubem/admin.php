<?php
session_start();

// Admin credentials
define('ADMIN_USER', 'admin');
define('ADMIN_PASS', 'admin123');

// Admin login check
if(!isset($_SESSION['is_admin'])){
    if($_SERVER['REQUEST_METHOD']==='POST' &&
       ($_POST['username'] ?? '') === ADMIN_USER &&
       ($_POST['password'] ?? '') === ADMIN_PASS){
        $_SESSION['is_admin'] = true;
        header("Location: admin.php");
        exit();
    } else {
        $error = $_SERVER['REQUEST_METHOD']==='POST' ? "Invalid admin credentials." : "";
        ?>
        <!doctype html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Admin Login</title>
            <style>
                body{font-family:Arial,sans-serif;background:#f0f2f5;display:flex;justify-content:center;align-items:center;height:100vh;margin:0;}
                .login-container{background:#fff;padding:40px;border-radius:10px;box-shadow:0 5px 20px rgba(0,0,0,0.1);text-align:center;width:350px;}
                h1{color:#007bff;margin-bottom:20px;}
                input{width:90%;padding:10px;margin:8px 0;border:1px solid #ccc;border-radius:5px;}
                button{padding:10px 20px;border:none;border-radius:5px;background:#007bff;color:#fff;cursor:pointer;}
                button:hover{background:#0056b3;}
                .error{color:red;margin-bottom:10px;}
            </style>
        </head>
        <body>
        <div class="login-container">
            <h1>Admin Login</h1>
            <?php if($error) echo "<div class='error'>".htmlspecialchars($error)."</div>"; ?>
            <form method="post">
                <input type="text" name="username" placeholder="Username" required><br>
                <input type="password" name="password" placeholder="Password" required><br>
                <button type="submit">Login</button>
            </form>
        </div>
        </body>
        </html>
        <?php exit();
    }
}

// Handle logout
if(isset($_GET['action']) && $_GET['action']==='logout'){
    session_unset();
    session_destroy();
    header("Location: admin.php");
    exit();
}

// Files
$USERS_FILE = __DIR__.'/users.json';
$PORT_FILE = __DIR__.'/portfolio.json';

// Ensure files exist
if(!file_exists($USERS_FILE)) file_put_contents($USERS_FILE, json_encode([], JSON_PRETTY_PRINT));
if(!file_exists($PORT_FILE)) file_put_contents($PORT_FILE, json_encode(new stdClass(), JSON_PRETTY_PRINT));

// Load data
$users = json_decode(file_get_contents($USERS_FILE), true);
$portfolios = json_decode(file_get_contents($PORT_FILE), true);

// Coin mapping
$coinMap = [
    'BTC'=>'bitcoin','ETH'=>'ethereum','BNB'=>'binancecoin','ADA'=>'cardano',
    'DOGE'=>'dogecoin','SOL'=>'solana','XRP'=>'ripple','LTC'=>'litecoin','DOT'=>'polkadot',
    'MATIC'=>'matic-network','AVAX'=>'avalanche-2','SHIB'=>'shiba-inu','LINK'=>'chainlink'
];

// Handle portfolio actions (add/edit/remove)
if($_SERVER['REQUEST_METHOD']==='POST'){
    $action = $_POST['action'] ?? '';
    $username = $_POST['username'] ?? '';
    $index = isset($_POST['index']) ? intval($_POST['index']) : null;

    if(!isset($portfolios[$username])) $portfolios[$username] = [];

    if($action==='edit' && $index!==null && isset($portfolios[$username][$index])){
        $portfolios[$username][$index]['amount'] = floatval($_POST['amount'] ?? 0);
    } elseif($action==='remove' && $index!==null && isset($portfolios[$username][$index])){
        array_splice($portfolios[$username], $index, 1);
    } elseif($action==='add'){
        $coin = strtoupper(trim($_POST['coin'] ?? ''));
        $amount = floatval($_POST['amount'] ?? 0);
        if($coin && $amount>0) $portfolios[$username][] = ['coin'=>$coin,'amount'=>$amount];
    }

    file_put_contents($PORT_FILE, json_encode($portfolios, JSON_PRETTY_PRINT));
    header("Location: admin.php");
    exit();
}

// Prepare all coins for live price fetch
$allCoinIds = [];
foreach($portfolios as $userPort){
    foreach($userPort as $coin){
        if(is_array($coin) && isset($coin['coin'])){
            $sym = strtoupper($coin['coin']);
            if(isset($coinMap[$sym])) $allCoinIds[] = $coinMap[$sym];
        }
    }
}
$allCoinIds = array_unique($allCoinIds);

// Fetch CoinGecko prices
$prices = [];
if(!empty($allCoinIds)){
    $url = 'https://api.coingecko.com/api/v3/simple/price?ids='.implode(',',$allCoinIds).'&vs_currencies=usd';
    $resp = @file_get_contents($url);
    if($resp!==false) $prices = json_decode($resp,true);
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Admin Dashboard</title>
<style>
body{font-family:Arial,sans-serif;background:#f7f8fa;margin:0;padding:0;}
nav{background:#007bff;color:#fff;padding:10px;display:flex;justify-content:space-between;}
nav a{color:#fff;text-decoration:none;font-weight:bold;}
.container{max-width:1000px;margin:20px auto;background:#fff;padding:20px;border-radius:10px;box-shadow:0 0 15px rgba(0,0,0,0.1);}
table{width:100%;border-collapse:collapse;margin-top:15px;}
table th,table td{padding:8px;border:1px solid #ddd;text-align:center;}
table th{background:#007bff;color:#fff;}
input{padding:5px;border-radius:4px;border:1px solid #ccc;width:70px;}
button{padding:5px 10px;border:none;border-radius:4px;background:#007bff;color:#fff;cursor:pointer;}
button.edit{background:orange;}
button.remove{background:red;}
h2{margin-top:20px;}
#ticker{background:#eee;padding:10px;overflow:hidden;white-space:nowrap;margin-bottom:15px;font-weight:bold;}
#ticker span{display:inline-block;padding:0 30px;}
</style>
</head>
<body>
<nav>
<div>💼 Admin Panel</div>
<div><a href="admin.php?action=logout">Logout</a></div>
</nav>

<div class="container">
<h1>Users & Portfolios</h1>

<!-- Live ticker -->
<div id="ticker">
<?php foreach($coinMap as $sym=>$id):
    $price = $prices[$id]['usd'] ?? 0; ?>
    <span data-coin="<?= $id ?>"><?= $sym ?>: $<?= number_format($price,2) ?></span>
<?php endforeach; ?>
</div>

<?php if(empty($users)): ?>
<p>No users yet.</p>
<?php else: ?>
<?php foreach($users as $user):
    $username = $user['username'];
    $full_name = $user['full_name'] ?? $username;
    $userPort = $portfolios[$username] ?? [];
    $totalValue = 0;
    foreach($userPort as $coin){
        if(!is_array($coin)) continue;
        $sym = strtoupper($coin['coin']);
        $amt = floatval($coin['amount'] ?? 0);
        $price = $prices[$coinMap[$sym]]['usd'] ?? 0;
        $totalValue += $amt * $price;
    }
?>
<h2><?= htmlspecialchars($full_name) ?> (<?= htmlspecialchars($username) ?>) - Total: $<span id="total-<?= $username ?>"><?= number_format($totalValue,2) ?></span></h2>

<table data-user="<?= $username ?>">
<thead>
<tr><th>Coin</th><th>Amount</th><th>Price (USD)</th><th>Value (USD)</th><th>Actions</th></tr>
</thead>
<tbody>
<?php foreach($userPort as $index=>$coin):
    if(!is_array($coin)) continue;
    $sym = strtoupper($coin['coin']);
    $amt = floatval($coin['amount'] ?? 0);
    $price = $prices[$coinMap[$sym]]['usd'] ?? 0;
    $value = $amt * $price;
?>
<tr data-coin="<?= $coinMap[$sym] ?>">
<td><?= htmlspecialchars($sym) ?></td>
<td><input type="number" step="0.0001" value="<?= $amt ?>" data-index="<?= $index ?>"></td>
<td>$<span class="price"><?= number_format($price,2) ?></span></td>
<td>$<span class="value"><?= number_format($value,2) ?></span></td>
<td>
<button class="save" data-username="<?= $username ?>" data-index="<?= $index ?>">Save</button>
<button class="remove" data-username="<?= $username ?>" data-index="<?= $index ?>">Remove</button>
</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
<?php endforeach; ?>
<?php endif; ?>
</div>

<script>
// Scroll ticker
const tickerCoins = <?= json_encode(array_values($coinMap)) ?>;
function scrollTicker(){document.getElementById('ticker').scrollLeft+=1;}
setInterval(scrollTicker,50);

// Update prices and total values
async function updatePrices(){
    try{
        const res = await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${tickerCoins.join(',')}&vs_currencies=usd`);
        const data = await res.json();

        tickerCoins.forEach(c=>{
            const el = document.querySelector(`#ticker span[data-coin="${c}"]`);
            if(el) el.innerText = c.toUpperCase() + ': $' + (data[c]?.usd??0).toFixed(2);

            document.querySelectorAll(`tr[data-coin="${c}"]`).forEach(row=>{
                const amount = parseFloat(row.querySelector('input').value);
                row.querySelector('.price').innerText = (data[c]?.usd??0).toFixed(2);
                row.querySelector('.value').innerText = ((data[c]?.usd??0)*amount).toFixed(2);
            });
        });

        document.querySelectorAll('table').forEach(tbl=>{
            const username = tbl.dataset.user;
            let total = 0;
            tbl.querySelectorAll('tr').forEach(row=>{
                const val = parseFloat(row.querySelector('.value').innerText)||0;
                total+=val;
            });
            const el = document.getElementById('total-'+username);
            if(el) el.innerText = total.toFixed(2);
        });
    }catch(e){console.error(e);}
}
updatePrices();
setInterval(updatePrices,10000);

// Save and remove buttons
document.addEventListener('click', e=>{
    if(e.target.matches('button.save')){
        const username=e.target.dataset.username,index=e.target.dataset.index,row=e.target.closest('tr'),amount=row.querySelector('input').value;
        const form=document.createElement('form'); form.method='post';
        form.innerHTML=`<input type="hidden" name="action" value="edit">
                        <input type="hidden" name="username" value="${username}">
                        <input type="hidden" name="index" value="${index}">
                        <input type="hidden" name="amount" value="${amount}">`;
        document.body.appendChild(form); form.submit();
    }
    if(e.target.matches('button.remove')){
        if(!confirm('Remove this coin?')) return;
        const username=e.target.dataset.username,index=e.target.dataset.index;
        const form=document.createElement('form'); form.method='post';
        form.innerHTML=`<input type="hidden" name="action" value="remove">
                        <input type="hidden" name="username" value="${username}">
                        <input type="hidden" name="index" value="${index}">`;
        document.body.appendChild(form); form.submit();
    }
});
</script>
</body>
</html>
